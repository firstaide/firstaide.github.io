import Image from "next/image"
import Link from "next/link"

import { Card, CardContent } from "@/components/ui/card"
import { Linkedin, Mail, Twitter, ExternalLink } from "lucide-react"

export default function CollaboratorsPage() {
  const collaborators = [
    {
      id: 1,
      name: "RED Design Ergonomics",
      role: "Associate Consultant",
      bio: "RED Design Ergonomics is a leading consultancy specializing in human-centered design and ergonomics. With a focus on creating environments that enhance human performance, health, and wellbeing, RED brings expertise in workplace design, product development, and accessibility.",
      website: "https://www.rdes.co.uk/",
      twitter: "https://twitter.com/RobinDEllis",
      image: "/placeholder.svg?height=400&width=400&text=RED+Design",
      // Note: Replace this placeholder with your actual image once provided
    },
    {
      id: 2,
      name: "Placeholder",
      role: "Placeholder",
      bio: "Sam is an expert in React and modern JavaScript frameworks with a passion for clean code.",
      image: "/placeholder.svg?height=400&width=400&text=Sam",
    },
  ]

  return (
    <div className="container py-12 md:py-16 lg:py-24">
      <div className="space-y-4 text-center">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">My Collaborators</h1>
        <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
          I'm fortunate to work with these talented individuals and organizations who help bring projects to life.
        </p>
      </div>
      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {collaborators.map((collaborator) => (
          <Card key={collaborator.id} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="relative">
                <Image
                  src={collaborator.image || "/placeholder.svg"}
                  alt={collaborator.name}
                  width={400}
                  height={400}
                  className="aspect-square object-cover w-full"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-0 left-0 p-4 text-white">
                  <h2 className="font-bold text-xl">{collaborator.name}</h2>
                  <p>{collaborator.role}</p>
                </div>
              </div>
              <div className="p-4 space-y-2">
                <p className="text-sm">{collaborator.bio}</p>
                <div className="flex gap-2 pt-2">
                  {collaborator.website && (
                    <Link
                      href={collaborator.website}
                      className="text-muted-foreground hover:text-foreground flex items-center gap-1"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <ExternalLink className="h-4 w-4" />
                      <span className="text-sm">Visit website</span>
                    </Link>
                  )}
                  <div className="ml-auto flex gap-2">
                    {collaborator.twitter && (
                      <Link
                        href={collaborator.twitter}
                        className="text-muted-foreground hover:text-foreground"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Twitter className="h-5 w-5" />
                        <span className="sr-only">Twitter</span>
                      </Link>
                    )}
                    {!collaborator.twitter && collaborator.id === 1 ? null : (
                      <Link href="#" className="text-muted-foreground hover:text-foreground"
                    )}
                    <Link href="#" className="text-muted-foreground hover:text-foreground">
                      <Linkedin className="h-5 w-5" />
                      <span className="sr-only">LinkedIn</span>
                    </Link>
                    <Link href="#" className="text-muted-foreground hover:text-foreground">
                      <Mail className="h-5 w-5" />
                      <span className="sr-only">Email</span>
                    </Link>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
