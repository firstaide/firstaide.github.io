import Image from "next/image"

export default function AboutPage() {
  return (
    <div className="container py-12 md:py-16 lg:py-24">
      <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
        <div>
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">About Me</h1>
          <div className="mt-4 space-y-4">
            <p>
              Adrian Woodcock.
              Product person and Service designer with over 20 years experience making user centered things.
            </p>
            <p>
              Some more text here. Design and human science back ground. bla bla bla.
            </p>
            <p>
              When I'm not working, more text making me sounds interesting and inspirationa.
            </p>
          </div>
          <div className="mt-8">
            <h2 className="text-2xl font-bold">Skills</h2>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div>
                <h3 className="font-semibold">Design</h3>
                <ul className="mt-2 space-y-1">
                  <li>UI/UX Design</li>
                  <li>Wireframing</li>
                  <li>Prototyping</li>
                  <li>Brand Identity</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold">Development</h3>
                <ul className="mt-2 space-y-1">
                  <li>HTML/CSS/JavaScript</li>
                  <li>React</li>
                  <li>Next.js</li>
                  <li>Responsive Design</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col gap-8">
          <div className="overflow-hidden rounded-lg">
            <Image
              src="/placeholder.svg?height=600&width=800&text=Profile+Photo"
              alt="Jane Doe"
              width={800}
              height={600}
              className="aspect-[4/3] object-cover"
            />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Experience</h2>
            <div className="mt-4 space-y-6">
              <div>
                <h3 className="font-semibold">Senior Designer at Creative Agency</h3>
                <p className="text-sm text-muted-foreground">2020 - Present</p>
                <p className="mt-2">
                  Leading design projects for major clients, collaborating with development teams, and mentoring junior
                  designers.
                </p>
              </div>
              <div>
                <h3 className="font-semibold">UI Designer at Tech Startup</h3>
                <p className="text-sm text-muted-foreground">2018 - 2020</p>
                <p className="mt-2">
                  Designed user interfaces for web and mobile applications, conducted user research, and implemented
                  design systems.
                </p>
              </div>
              <div>
                <h3 className="font-semibold">Freelance Designer</h3>
                <p className="text-sm text-muted-foreground">2016 - 2018</p>
                <p className="mt-2">
                  Worked with various clients on branding, web design, and digital marketing projects.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
