import type React from "react"
import { Inter } from "next/font/google"
import Link from "next/link"
import { Folder, Home, User, Users } from "lucide-react"

import { ThemeProvider } from "@/components/theme-provider"
import { Button } from "@/components/ui/button"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Adrian Woodcock",
  description: "Professional showcase of design and development work",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <div className="flex min-h-screen flex-col">
            <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
              <div className="container pl-8 md:pl-10 flex h-16 items-center">
                <Link href="/" className="font-bold text-xl mr-8">
                  Adrian Woodcock
                </Link>
                <nav className="flex items-center space-x-4 lg:space-x-6">
                  <Button asChild variant="ghost" className="text-sm font-medium">
                    <Link href="/" className="flex items-center gap-1">
                      <Home className="h-4 w-4" />
                      Home
                    </Link>
                  </Button>
                  <Button asChild variant="ghost" className="text-sm font-medium">
                    <Link href="/about" className="flex items-center gap-1">
                      <User className="h-4 w-4" />
                      About
                    </Link>
                  </Button>
                  <Button asChild variant="ghost" className="text-sm font-medium">
                    <Link href="/projects" className="flex items-center gap-1">
                      <Folder className="h-4 w-4" />
                      Projects
                    </Link>
                  </Button>
                  <Button asChild variant="ghost" className="text-sm font-medium">
                    <Link href="/collaborators" className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      Collaborators
                    </Link>
                  </Button>
                </nav>
              </div>
            </header>
            <main className="flex-1">
              <div className="pl-8 md:pl-10">{children}</div>
            </main>
            <footer className="border-t py-6">
              <div className="container pl-8 md:pl-10 flex flex-col items-center justify-between gap-4 md:flex-row">
                <p className="text-center text-sm text-muted-foreground md:text-left">
                  &copy; {new Date().getFullYear()} Adrian Woodcock. All rights reserved.
                </p>
                <div className="flex items-center gap-4">
                  <Link href="#" className="text-sm text-muted-foreground hover:underline">
                    Terms
                  </Link>
                  <Link href="#" className="text-sm text-muted-foreground hover:underline">
                    Privacy
                  </Link>
                  <Link href="#" className="text-sm text-muted-foreground hover:underline">
                    Contact
                  </Link>
                </div>
              </div>
            </footer>
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}


import './globals.css'