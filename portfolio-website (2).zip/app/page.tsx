import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export default function Home() {
  const sections = [
    {
      id: "about",
      title: "About",
      description:
        "Adrian Woodcock. Product person and Service designer with over 20 years experience making user centered things. Design and human science background with a passion for creating intuitive, accessible experiences.",
      image: "/placeholder.svg?height=300&width=500&text=About",
      link: "/about",
    },
    {
      id: "projects",
      title: "Projects",
      description:
        "Explore my portfolio of work across various domains including Pandemic Preparedness, Help with Fees, Global Billing, Export Wins, Data Science, Self Employment, and Kickstart initiatives. Each project demonstrates a user-centered approach to solving complex problems.",
      image: "/placeholder.svg?height=300&width=500&text=Projects",
      link: "/projects",
    },
    {
      id: "collaborators",
      title: "Collaborators",
      description:
        "Meet the talented individuals I work with to bring projects to life. My network includes UX designers, developers, project managers, content strategists, and motion designers who contribute their expertise to create exceptional outcomes.",
      image: "/placeholder.svg?height=300&width=500&text=Collaborators",
      link: "/collaborators",
    },
  ]

  return (
    <div className="container py-12 md:py-16 lg:py-24">
      <div className="space-y-4 mb-12">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Adrian Woodcock</h1>
        <p className="max-w-[700px] text-muted-foreground md:text-xl">
          Welcome to my professional showcase of design and development work.
        </p>
      </div>

      <div className="space-y-16">
        {sections.map((section) => (
          <div key={section.id} id={section.id} className="scroll-mt-20">
            <div className="grid gap-6 lg:grid-cols-[2fr_3fr] items-start">
              <div>
                <h2 className="text-2xl font-bold mb-3">{section.title}</h2>
                <p className="text-muted-foreground mb-4">{section.description}</p>
                <Button variant="outline" size="sm" asChild className="group">
                  <Link href={section.link}>
                    Learn more
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </Button>
              </div>
              <div className="relative overflow-hidden rounded-lg">
                <Image
                  src={section.image || "/placeholder.svg"}
                  alt={section.title}
                  width={500}
                  height={300}
                  className="w-full object-cover transition-all hover:scale-105 aspect-[5/3]"
                />
              </div>
            </div>
            {section.id !== sections[sections.length - 1].id && <div className="my-16 h-px bg-border" />}
          </div>
        ))}
      </div>
    </div>
  )
}
